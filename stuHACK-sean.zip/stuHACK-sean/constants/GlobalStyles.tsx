import { StyleSheet, View, Pressable, Text } from 'react-native';

const GlobalSyles = StyleSheet.create({
    button: {

    }
}
)